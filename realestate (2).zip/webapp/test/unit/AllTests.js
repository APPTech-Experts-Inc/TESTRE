sap.ui.define([
	"com/apptech/realestate/test/unit/controller/Login.controller"
], function () {
	"use strict";
});